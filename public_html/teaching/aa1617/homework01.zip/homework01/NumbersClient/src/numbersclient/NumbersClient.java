package numbersclient;

import numbers.*;

public class NumbersClient {

    public static void main(String[] args) {
        Numbers numbersService = new Numbers();
        NumbersPortType numbers = numbersService.getNumbersPort();
        
        // Successful invocations
        int n1=25,n2=145;
        System.out.println("=========================");
        System.out.println("Numbers: " + n1 + "," + n2);
        try {
            System.out.println("GCD: " + numbers.gcd(n1, n2));
            System.out.println("LCM: " + numbers.lcm(n1, n2));
        } catch(NumbersException_Exception e) {
            System.err.println("Both numbers should be non-negative.");
        }
        
        // Failing invocations
        n1=-1;
        System.out.println("=========================");
        System.out.println("Numbers: " + n1 + "," + n2);
        try {
            System.out.println("GCD: " + numbers.gcd(n1, n2));
            System.out.println("LCM: " + numbers.lcm(n1, n2));
        } catch(NumbersException_Exception e) {
            System.err.println("Both numbers should be non-negative.");
        }
        
    }
}
