package numbers;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

@WebService(name="NumbersPortType")
public interface INumbers {
    
    @WebMethod(operationName="GCD")
    @WebResult(name="gcd")
    public int gcd(
      @WebParam(name="num1") int a,
      @WebParam(name="num2") int b
    ) throws NumbersException;
    
    @WebMethod(operationName="LCM")
    @WebResult(name="lcm")
    public int lcm(
      @WebParam(name="num1") int a,
      @WebParam(name="num2") int b
    ) throws NumbersException;
}
