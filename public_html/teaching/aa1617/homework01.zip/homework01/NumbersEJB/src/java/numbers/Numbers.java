package numbers;

import javax.jws.WebService;
import javax.ejb.Stateless;

@WebService(serviceName="Numbers",
        portName="NumbersPort",
        endpointInterface="numbers.INumbers")
@Stateless()
public class Numbers implements INumbers {

    private int _gcd(int a, int b) throws NumbersException {
        if(a<0 || b<0) throw new NumbersException();
        while(a!=b) {
            if(a>b) a=a-b;
            else b=b-a;
        }
        return a;
    }
    
    public int gcd(int a, int b) throws NumbersException {
        return _gcd(a,b);
    }

    public int lcm(int a, int b) throws NumbersException {
        return (a*b)/_gcd(a,b);
    }
}
