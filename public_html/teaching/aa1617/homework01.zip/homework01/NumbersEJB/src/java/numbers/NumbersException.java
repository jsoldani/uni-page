package numbers;

import javax.xml.ws.WebFault;

@WebFault(name="NegativeParameters")
public class NumbersException extends Exception {
    public NumbersException() { super(); }
}
