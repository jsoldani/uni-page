package infofromipclient;

import infofromip.InfoFromIP;
import infofromip.InfoFromIPPortType;

public class InfoFromIPClient {

    public static void main(String[] args) {
        InfoFromIP ifipService = new InfoFromIP();
        InfoFromIPPortType ifip = ifipService.getInfoFromIPPort();
        
        String ip = "8.8.8.8";
        System.out.println("Currency: " + ifip.getCurrency(ip));
    }
}
