package infofromip;

import com.cdyne.ws.IP2Geo;
import com.cdyne.ws.IP2GeoSoap;
import com.cdyne.ws.IPInformation;
import javax.jws.WebService;
import javax.ejb.Stateless;
import net.webservicex.Country;
import net.webservicex.CountrySoap;

@WebService(serviceName = "InfoFromIP",
        portName="InfoFromIPPort",
        endpointInterface="infofromip.IInfoFromIP")
@Stateless()
public class InfoFromIP implements IInfoFromIP{

    public String getCurrency(String ipAddress) {
        // Retrieving ip geographical information
        IP2Geo ip2geoService = new IP2Geo();
        IP2GeoSoap ip2geo = ip2geoService.getIP2GeoSoap();
        IPInformation ipInfo = ip2geo.resolveIP(ipAddress, "0");
        
        // Retrieving currency (from country)
        Country countryService = new Country();
        CountrySoap country = countryService.getCountrySoap();
        String currency = country.getCurrencyByCountry(ipInfo.getCountry());
        
        // Parsing currency to print it properly
        String currencyName = extractTagContent(currency,"Currency");
        return currencyName;
    }
    
    private static String extractTagContent(String sourceString, String tagName) {
        String startTag = "<" + tagName + ">";
        String endTag = "</" + tagName + ">";
        int start = sourceString.indexOf(startTag) + startTag.length();
        int end = sourceString.indexOf(endTag);
        return sourceString.substring(start, end);
    }

}
