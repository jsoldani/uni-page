package infofromip;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

@WebService(name="InfoFromIPPortType")
public interface IInfoFromIP {
    
    @WebMethod(operationName="GetCurrency")
    @WebResult(name="Currency")
    public String getCurrency(@WebParam(name="IPAddress")String ipAddress);
   
}
