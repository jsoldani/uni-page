package infofromipapp;

import com.cdyne.ws.IP2Geo;
import com.cdyne.ws.IP2GeoSoap;
import com.cdyne.ws.IPInformation;
import net.webservicex.Country;
import net.webservicex.CountrySoap;

public class InfoFromIPApp {

    public static void main(String[] args) {
        String ip = "8.8.8.8"; // Google DNS

        // Retrieving ip geographical information
        IP2Geo ip2geoService = new IP2Geo();
        IP2GeoSoap ip2geo = ip2geoService.getIP2GeoSoap();
        IPInformation ipInfo = ip2geo.resolveIP(ip, "0");
        System.out.println("City: " + ipInfo.getCity());
        System.out.println("Country: " + ipInfo.getCountry());
        
        // Retrieving currency (from country)
        Country countryService = new Country();
        CountrySoap country = countryService.getCountrySoap();
        String currency = country.getCurrencyByCountry(ipInfo.getCountry());
        
        // Parsing currency to print it properly
        String currencyName = extractTagContent(currency,"Currency");
        System.out.println("Currency: " + currencyName);
        String currencyCode = extractTagContent(currency,"CurrencyCode");
        System.out.println("Currency code: " + currencyCode);
        
    }
    
    private static String extractTagContent(String sourceString, String tagName) {
        String startTag = "<" + tagName + ">";
        String endTag = "</" + tagName + ">";
        int start = sourceString.indexOf(startTag) + startTag.length();
        int end = sourceString.indexOf(endTag);
        return sourceString.substring(start, end);
    }
}
