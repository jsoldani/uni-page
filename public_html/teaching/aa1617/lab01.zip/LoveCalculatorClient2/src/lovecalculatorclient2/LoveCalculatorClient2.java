package lovecalculatorclient2;

import lovecalculator.*;

public class LoveCalculatorClient2 {
    public static void main(String[] args) {
        LoveCalculator lcService = new LoveCalculator();
        LoveCalculatorPortType lcPort = lcService.getLoveCalculatorPort();
        try {
            int affinity = lcPort.percentage("", "Minnie Mouse");
            System.out.println(affinity);
        } catch (LoveCalculatorFault_Exception ex) {
            System.err.println("Error");
        }
    }
}