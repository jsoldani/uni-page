package loveCalculatorPackage;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

@WebService(name="LoveCalculatorPortType")
public interface ILoveCalculator {
    @WebMethod(operationName="percentage")
    @WebResult(name="Affinity")
    public int compute(
            @WebParam(name="Lover1") String name1,
            @WebParam(name="Lover2") String name2) 
            throws LoveCalculatorFault; 
}
