package loveCalculatorPackage;

import javax.xml.ws.WebFault;

@WebFault(name="EmptyNameFault")
public class LoveCalculatorFault extends Exception {
    public LoveCalculatorFault() { super(); }
}