package loveCalculatorPackage;

import javax.ejb.Stateless;
import javax.jws.WebService;

@WebService(serviceName = "LoveCalculator", portName = "LoveCalculatorPort", endpointInterface = "loveCalculatorPackage.ILoveCalculator")
@Stateless
public class LoveCalculator implements ILoveCalculator {
    public int compute(String name1, String name2) throws 	LoveCalculatorFault {
        if(name1.length()==0 || name2.length()==0)
            throw new LoveCalculatorFault();
        return Math.abs(name1.hashCode()+name2.hashCode())%100;
    }
}
