@javax.xml.bind.annotation.XmlSchema(namespace = "http://loveCalculatorPackage/")
package lovecalculator;
