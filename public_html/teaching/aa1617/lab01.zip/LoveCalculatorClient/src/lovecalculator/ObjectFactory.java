
package lovecalculator;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the lovecalculator package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _PercentageResponse_QNAME = new QName("http://loveCalculatorPackage/", "percentageResponse");
    private final static QName _EmptyNameFault_QNAME = new QName("http://loveCalculatorPackage/", "EmptyNameFault");
    private final static QName _Percentage_QNAME = new QName("http://loveCalculatorPackage/", "percentage");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: lovecalculator
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Percentage }
     * 
     */
    public Percentage createPercentage() {
        return new Percentage();
    }

    /**
     * Create an instance of {@link PercentageResponse }
     * 
     */
    public PercentageResponse createPercentageResponse() {
        return new PercentageResponse();
    }

    /**
     * Create an instance of {@link LoveCalculatorFault }
     * 
     */
    public LoveCalculatorFault createLoveCalculatorFault() {
        return new LoveCalculatorFault();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PercentageResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://loveCalculatorPackage/", name = "percentageResponse")
    public JAXBElement<PercentageResponse> createPercentageResponse(PercentageResponse value) {
        return new JAXBElement<PercentageResponse>(_PercentageResponse_QNAME, PercentageResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LoveCalculatorFault }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://loveCalculatorPackage/", name = "EmptyNameFault")
    public JAXBElement<LoveCalculatorFault> createEmptyNameFault(LoveCalculatorFault value) {
        return new JAXBElement<LoveCalculatorFault>(_EmptyNameFault_QNAME, LoveCalculatorFault.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Percentage }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://loveCalculatorPackage/", name = "percentage")
    public JAXBElement<Percentage> createPercentage(Percentage value) {
        return new JAXBElement<Percentage>(_Percentage_QNAME, Percentage.class, null, value);
    }

}
