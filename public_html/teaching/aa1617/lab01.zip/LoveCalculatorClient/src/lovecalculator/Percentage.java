
package lovecalculator;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for percentage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="percentage">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Lover1" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Lover2" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "percentage", propOrder = {
    "lover1",
    "lover2"
})
public class Percentage {

    @XmlElement(name = "Lover1")
    protected String lover1;
    @XmlElement(name = "Lover2")
    protected String lover2;

    /**
     * Gets the value of the lover1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLover1() {
        return lover1;
    }

    /**
     * Sets the value of the lover1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLover1(String value) {
        this.lover1 = value;
    }

    /**
     * Gets the value of the lover2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLover2() {
        return lover2;
    }

    /**
     * Sets the value of the lover2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLover2(String value) {
        this.lover2 = value;
    }

}
