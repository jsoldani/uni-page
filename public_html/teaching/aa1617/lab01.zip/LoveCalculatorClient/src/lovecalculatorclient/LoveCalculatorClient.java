package lovecalculatorclient;

import lovecalculator.*;

public class LoveCalculatorClient {
    public static void main(String[] args) {
        LoveCalculator lcService = new LoveCalculator();
        LoveCalculatorPortType lcPort = lcService.getLoveCalculatorPort();
        try {
            int affinity = lcPort.percentage("Mickey Mouse", "Minnie Mouse");
            System.out.println(affinity);
        } catch (LoveCalculatorFault_Exception ex) {
            System.err.println("Error");
        }
    }
}